exports.handler = (event, context, callback) => {
   callback(null, {
       statusCode: "200",
       body: "Hello from My CloudFormation Deployed lambda service",
       headers: {
           "Content-Type": "text/html",
       },
   });
};